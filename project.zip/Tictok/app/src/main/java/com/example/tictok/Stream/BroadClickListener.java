package com.example.tictok.Stream;

public interface BroadClickListener {

    public void jump(int position);

}
