package com.example.tictok.Stream;

public class DataStream {

}
